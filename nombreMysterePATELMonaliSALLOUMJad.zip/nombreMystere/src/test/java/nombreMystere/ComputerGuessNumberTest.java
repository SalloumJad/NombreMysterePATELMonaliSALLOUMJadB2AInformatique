package nombreMystere;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class ComputerGuessNumberTest {
	
	@Test
	public void testCompareTry1() { // Tests v�rifiant si la conversion des valeurs en ASCII fonctionne avec les conditions voulues.
		// Arrange
		int try1 = 2;
		
		int number = 2579;
		
		ComputerGuessNumber cn = new ComputerGuessNumber();
		
		// Act
		boolean result = cn.compareTry1(try1, number);
		
		// Assert
		assertEquals(true, result);
	}
	
	@Test
	public void testCompareTry2() {
		// Arrange
		int try2 = 5;
		
		int number = 2579;
		
		ComputerGuessNumber cn = new ComputerGuessNumber();
		
		// Act
		boolean result = cn.compareTry2(try2, number);
		
		// Assert
		assertEquals(true, result);
	}
	
	@Test
	public void testCompareTry3() {
		// Arrange
		int try3 = 7;
		
		int number = 2579;
		
		ComputerGuessNumber cn = new ComputerGuessNumber();
		
		// Act
		boolean result = cn.compareTry3(try3, number);
		
		// Assert
		assertEquals(true, result);
	}
	
	@Test
	public void testCompareTry4() {
		// Arrange
		int try4 = 9;
		
		int number = 2579;
		
		ComputerGuessNumber cn = new ComputerGuessNumber();
		
		// Act
		boolean result = cn.compareTry4(try4, number);
		
		// Assert
		assertEquals(true, result);
	}
	
	
	@Test
	public void winActTest() { // test v�rifiant que la fonction winAct fonctionne en fonction du nombre choisit. (entre 1 et 3)
		// Arrange
		int choice = 3;
		boolean result;
		
		ComputerGuessNumber cn = new ComputerGuessNumber();
		
		// Act
		result = cn.winAct(choice);
		
		// Assert
		assertTrue(result);
	}
	
	@Test
	public void convertFailIntoResultTest() { // test v�rifiant que le r�sultat enregistr� (et print plus tard) est le m�me que celui voulu.
		// Arrange
		ComputerGuessNumber cn = new ComputerGuessNumber();
		int total = 2589;
		char[] splitNumber = {'0','5','9','3'};
		String result;
		
		// Act
		result = cn.convertFailIntoResult(total, splitNumber);
		
		// Assert
		assertEquals("-=+-", result);
	}
	
	
}

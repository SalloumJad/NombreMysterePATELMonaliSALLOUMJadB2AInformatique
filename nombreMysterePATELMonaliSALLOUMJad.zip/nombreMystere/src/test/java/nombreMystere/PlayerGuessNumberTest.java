package nombreMystere;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class PlayerGuessNumberTest {

	@Test
	public void convertResultTest() { 
		// Fonction v�rifiant si le r�sultat affich� par la comparaison de la valeur entr�e par l'utilisateur et celle g�n�r�e al�atoirement est correcte.
		
		// Arrange
		char[] splitChoice = {'1', '0', '9', '6'};
		char[] splitNumber = {'1', '2', '3', '4'};
		String result;
		PlayerGuessNumber pn = new PlayerGuessNumber();
		
		// Act
		result = pn.convertResult(splitChoice, splitNumber);
		
		// Assert
		assertEquals("=+--", result);
	}
	
	@Test
	public void playerMenuTest() {
		// Fonction v�rifiant si les menus du joueur s'effectuent sans probl�mes avec un choix fonctionnel de la part du joueur.
		
		// Arrange
		int choice = 2;
		boolean result;
		PlayerGuessNumber pn = new PlayerGuessNumber();
		
		// Act
		result = pn.playerMenu(choice);
		
		// Assert
		assertTrue(result);
	}
}

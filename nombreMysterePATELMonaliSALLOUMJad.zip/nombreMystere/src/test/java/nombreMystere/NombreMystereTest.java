package nombreMystere;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class NombreMystereTest {

	public void mainMenuTest() { // Test v�rifiant si les options du menu fonctionnent sans probl�me.
		// Arrange
		int choice = 1;
		boolean  result;
		NombreMystere nm = new NombreMystere();
		
		// Act
		result = NombreMystere.mainMenu(choice);
		
		// Assert
		assertTrue(result);
	}
}

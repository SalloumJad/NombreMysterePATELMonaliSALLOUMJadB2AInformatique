package nombreMystere;

import java.util.Random;
import java.util.Scanner;

public class PlayerGuessNumber {
	// Param�tres g�n�raux
	private int number;
	private int vies;
	
	public PlayerGuessNumber() { // initialisation des valeurs lors de l'appel du constructeur. Ici, number est g�n�r� al�atoirement pour d�finir le nombre � trouver pour le joueur.
		Random r = new Random();
		while (r.nextInt() < 1000) {
			r = new Random();
		}
		this.number = r.nextInt(9999 - 1000) + 1000;
		this.vies = 10;
	}
	
	public void playGame() {
		System.out.println("\nVous allez deviner un nombre a 4 chiffres. \nL'ordinateur repondra avec un +, - ou = a l'emplacement de chaque chiffre. Vous avez 10 vies.\nBonne chance!\n\n");
		
		String charNumber = String.valueOf(this.number);
		
		char[] splitNumber = charNumber.toCharArray();
		
		while (this.vies >= 1) { // tant que le joueur � des essais
			int choice = 0;
			
			String charChoice = ""; // Cr�ation de charChoice, afin de stocker la valeur du joueur en charact�re
			try {
				Scanner sc = new Scanner(System.in);
				while ((choice < 1000 || choice > 9999)) {
					System.out.println("Entrez un nombre a 4 chiffres\n");
					choice = sc.nextInt();
				}
				charChoice = String.valueOf(choice);
			}
			catch(Exception e) { 
				// Erreur si le joueur � entr� un charact�re et non un nombre
				System.out.println("\nERREUR: Vous avez entre un charactere et non un nombre. Veuillez reessayer. Relancement du mode de jeu.\n\n");
				this.playGame();
			}
			
			
			char[] splitChoice = charChoice.toCharArray(); // S�pare la valeur du joueur afin de pouvoir comparer les chiffres s�par�ment.

			
			
			if(choice != this.number) { // Si le joueur n'a pas devin� le nombre
				String result = convertResult(splitChoice, splitNumber);
				
				this.vies--;
				
				System.out.println("Il vous reste " + this.vies + " vies !\n");
				
				System.out.println("Le resultat est le suivant :\n" + result);
			}
			else { // Si le joueur � gagn�
				try {
					Scanner scan = new Scanner(System.in);
					while ((choice < 1 || choice > 3)) {
						System.out.println("Vous avez gagn�!\n\nRejouer: 1\nRetour au menu: 2\nQuitter: 3");
						choice = scan.nextInt();
					}
				}
				catch(Exception e) { 
					// Erreur si le joueur entre un charact�re et non un nombre
					System.out.println("\nERREUR: Vous avez entre un charactere et non un nombre. Veuillez reessayer. Relancement du jeu.\n\n");
					NombreMystere.main(null);
				}
				
				playerMenu(choice);
				
			}
		}
		if (this.vies <=0) { // Si le joueur � perdu
			System.out.println("Vous avez perdu !\nLa reponse etait : " + this.number + " !\n");
			int choice = 0;
			try {
				Scanner scan = new Scanner(System.in);
				while ((choice  < 1 || choice > 3)) {
					System.out.println("\nRejouer: 1\nRetour au menu: 2\nQuitter: 3");
					choice = scan.nextInt();
				}
			}
			catch(Exception e) { 
				// Erreur si le joueur � entr� un charact�re et non un nombre.
				System.out.println("\nERREUR: Vous avez entre un charactere et non un nombre. Veuillez reessayer. Relancement du mode de jeu.\n\n");
				this.playGame();
			}
			
			playerMenu(choice);
		}
	}
	
	public String convertResult(char[] splitChoice, char[] splitNumber) { // Cr�e l'affichage donn� apr�s comparaison de la valeur entr�e par le joueur et la valeur g�n�r�e al�atoirement � trouver.
		String result = "";
		if (Integer.valueOf(splitChoice[0]) < Integer.valueOf(splitNumber[0])) { // Affiche + si le r�sultat est plus grand que celui envoy�
			result = result + "+";
		}
		else if(Integer.valueOf(splitChoice[0]) > Integer.valueOf(splitNumber[0])) { // Affiche - si le r�sultat est plus petit que celui envoy�
			result = result + "-";
		}
		else if(Integer.valueOf(splitChoice[0]) == Integer.valueOf(splitNumber[0])) { // Affiche = si le r�sultat est �gal � celui envoy�
			result = result + "=";
		}
		
		
		if (Integer.valueOf(splitChoice[1]) < Integer.valueOf(splitNumber[1])) {
			result = result + "+";
		}
		else if(Integer.valueOf(splitChoice[1]) > Integer.valueOf(splitNumber[1])) {
			result = result + "-";
		}
		else if(Integer.valueOf(splitChoice[1]) == Integer.valueOf(splitNumber[1])) {
			result = result + "=";
		}
		
		
		if (Integer.valueOf(splitChoice[2]) < Integer.valueOf(splitNumber[2])) {
			result = result + "+";
		}
		else if(Integer.valueOf(splitChoice[2]) > Integer.valueOf(splitNumber[2])) {
			result = result + "-";
		}
		else if(Integer.valueOf(splitChoice[2]) == Integer.valueOf(splitNumber[2])) {
			result = result + "=";
		}
		
		
		if (Integer.valueOf(splitChoice[3]) < Integer.valueOf(splitNumber[3])) {
			result = result + "+";
		}
		else if(Integer.valueOf(splitChoice[3]) > Integer.valueOf(splitNumber[3])) {
			result = result + "-";
		}
		else if(Integer.valueOf(splitChoice[3]) == Integer.valueOf(splitNumber[3])) {
			result = result + "=";
		}
		
		return result;
	}
	
	public boolean playerMenu(int choice) { 
		// Menu s'affichant apr�s que le joueur ait gagn� la partie. Retourne true ou false pour les tests.
		if (choice == 1) {
			Random r = new Random();
			while (r.nextInt() < 1000) {
				r = new Random();
			}
			this.number = r.nextInt(9999 - 1000) + 1000;
			this.vies = 10;
			this.playGame();
			return true;
		}
		else if (choice == 2) {
			NombreMystere.main(null);
			return true;
		}
		else if (choice == 3) {
			System.exit(1);
			return true;
		}
		return false;
	}
}

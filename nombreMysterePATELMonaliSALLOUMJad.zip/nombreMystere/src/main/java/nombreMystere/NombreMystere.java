package nombreMystere;

import java.util.Scanner;

public class NombreMystere {

	public static void main(String[] args) {		
		System.out.println("Bienvenue au Nombre Mysteres! Choisissez 1 pour deviner un nombre et 2 pour faire deviner un nombre!\n\n");
		
		int choice = 0;
		
		try {
			Scanner sc = new Scanner(System.in);
			while ((choice < 1 || choice > 2)) {
				choice = sc.nextInt();
			}
		}
		catch(Exception e) {
			System.out.println("\nERREUR: Vous avez entre un charactere et non un nombre. Veuillez reessayer.\n\n");
			main(null);
		}
		
		mainMenu(choice);
	}
	
	public static boolean mainMenu(int choice) { // Lance le mode de jeu en fonction du choix du joueur. renvoie true ou false pour les tests.
		if(choice == 1) {
			PlayerGuessNumber p = new PlayerGuessNumber();
			p.playGame();
			return true;
		}
		else if(choice == 2) {
			ComputerGuessNumber c = new ComputerGuessNumber();
			c.playGame();
			return true;
		}
		return false;
	}
}

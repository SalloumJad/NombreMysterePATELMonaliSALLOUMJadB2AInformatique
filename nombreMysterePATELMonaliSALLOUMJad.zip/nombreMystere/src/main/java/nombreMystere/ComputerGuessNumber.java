package nombreMystere;

import java.util.Random;
import java.util.Scanner;

public class ComputerGuessNumber {
	// Param�tres g�n�raux
	private int number;
	private int vies;
	
	// Variables stockant les essais de chaque emplacement
	private int try1;
	private int try2;
	private int try3;
	private int try4;
	
	// Variables des valeurs minimum possibles des essais
	private int min1;
	private int min2;
	private int min3;
	private int min4;
	
	// Variables des valeurs maximum possibles des essais
	private int max1;
	private int max2;
	private int max3;
	private int max4;
	
	public ComputerGuessNumber() {
		this.number = 0;
		this.vies = 10;
		this.try1 = 5; //L'ordinateur commence par 5, car c'est le choix le plus efficace afin de trouver le r�sultat.
		this.try2 = 5; //L'ordinateur va continuer en r�tr�cissant la range de nombre al�atoires.
		this.try3 = 5;
		this.try4 = 5;
		
		this.max1 = 9;
		this.max2 = 9;
		this.max3 = 9;
		this.max4 = 9;
		
		this.min1 = 0;
		this.min2 = 0;
		this.min3 = 0;
		this.min4 = 0;
		
	}
	
	public void playGame() {
		System.out.println("\nVous allez faire deviner un nombre a 4 chiffres. \nIl y aura une reponse avec un +, - ou = a l'emplacement de chaque chiffre. L'ordinateur a 10 vies.\nBonne chance!\n\n");
		
		// Cr�ation d'une seed random. Celle-ci sera recr��e plusieurs fois afin d'en tirer des r�sultats diff�rents.
		Random r = new Random();
		
		try {
			Scanner sc = new Scanner(System.in);
			while ((this.number < 1000 || this.number > 9999)) {
				System.out.println("Entrez un nombre a 4 chiffres\n");
				this.number = sc.nextInt();
			}
		}
		catch(Exception e) { // Erreur dans le cas o� le joueur entre un charact�re et non un nombre.
			System.out.println("\nERREUR: Vous avez entre un charactere et non un nombre. Veuillez reessayer. Relancement du mode de jeu.\n\n");
			this.playGame();
		}
		// S�paration de l'entr�e utilisateur en 4 charact�res correspondants au chiffre. Celui-ci est en valeur ASCII lors des conditions.
		String charNumber = String.valueOf(this.number);
		
		char[] splitNumber = charNumber.toCharArray();
		
		while (this.vies > 0) {
			System.out.println("\nL'ordinateur essaye un nombre !\n");
			
			int total = this.try1 * 1000 + this.try2 * 100 + this.try3 * 10 + this.try4;
			
			if (total != this.number) {				
				// Fonction qui permet d'enregistrer un string comportant les comparaisons chiffre par chiffre. Exemple: +=--
				String result = convertFailIntoResult(total, splitNumber);
				
				System.out.println("\n" + result + "\n");
				
				System.out.println("\nIl reste " + this.vies + " vies a l'ordinateur !\n");
				System.out.println("\nL'ordinateur s'est trompe! Son essai :\n" + total +"\n");
				
				if (this.vies <= 0) { // Si le joueur gagne
					int choice = 0;
					
					try {
						Scanner scan = new Scanner(System.in);
						while ((choice < 1 || choice > 3)) {
							System.out.println("Vous avez gagn�!\n\nRejouer: 1\nRetour au menu: 2\nQuitter: 3");
							choice = scan.nextInt();
						}
					}
					catch(Exception e) {
						System.out.println("\nERREUR: Vous avez entre un charactere et non un nombre. Veuillez reessayer. Relancement du mode de jeu.\n\n");
						this.playGame();
					}
					
					winAct(choice); // Finit la partie et propose de recommencer, retourner au menu ou quitter.
				}
			}
			else { // rappel: else de if total != this.number, soit si l'ordinateur gagne.
				System.out.println("Vous avez perdu ! L'ordinateur a trouve la bonne reponse !\n");
				int choice = 0;
				try {
					Scanner scan = new Scanner(System.in);
					while ((choice  < 1 || choice > 3)) {
						System.out.println("\nRejouer: 1\nRetour au menu: 2\nQuitter: 3");
						choice = scan.nextInt();
					}
				}
				catch(Exception e) { // Erreur si le joueur entre un charact�re autre qu'un nombre
					System.out.println("\nERREUR: Vous avez entre un charactere et non un nombre. Veuillez reessayer. Relancement du mode de jeu.\n\n");
					this.playGame();
				}
				
				
				if (choice == 1) {
					this.number = 0; // R�attribution des valeurs initiales afin de relancer le jeu, �tant donn� que le constructeur n'est pas appel�.
					this.vies = 10;
					this.try1 = 5;
					this.try2 = 5;
					this.try3 = 5;
					this.try4 = 5;
					
					this.max1 = 9;
					this.max2 = 9;
					this.max3 = 9;
					this.max4 = 9;
					
					this.min1 = 0;
					this.min2 = 0;
					this.min3 = 0;
					this.min4 = 0;
					this.playGame();
				}
				else if (choice == 2) { // Appel de la fonction main, soit un red�marrage de l'application.
					NombreMystere.main(null);
				}
				else if (choice == 3) { // Quitter l'application.
					System.exit(1);
				}
			}
			
			
			if (!compareTry1(this.try1, this.number)) { // Fonction permettant de tester si try1 == number. Renvoie false si ce n'est pas le cas. Etant donn� que nous voulons le cas o� c'est false, on prend l'inverse du r�sultat pour faire marcher la fonction.
				if(this.try1 > (Integer.valueOf(splitNumber[0]) - '0')) {
					// La valeur du char[] traduite en int est une valeur ASCII, ce qui ne correspond pas au nombre voulu. Pour trouver la vraie valeur, on r�duit celle-ci par la valeur du '0' de ASCII, ce qui la change en sa valeur voulue.
					
					r = new Random();
					this.max1 = this.try1; // Si le nombre trouv� est plus grand, alors le nouveau maximum deviens le nombre test�. l'ordinateur fait ainsi un autre lanc� al�atoire.
					
					this.try1 = r.nextInt(this.max1 - this.min1) + this.min1;
				}
				else {
					r = new Random();
					this.min1 = this.try1; // Si le nombre trouv� est plus petit, alors le nouveau minimum deviens le nombre test�.
					
					this.try1 = r.nextInt(this.max1 - this.min1) + this.min1;
				}
			}
			
			if (!compareTry2(this.try2, this.number)) {
				if(this.try2 > (Integer.valueOf(splitNumber[1]) - '0')) {
					r = new Random();
					this.max2 = this.try2;
					
					this.try2 = r.nextInt(this.max2 - this.min2) + this.min2;
				}
				else {
					r = new Random();
					this.min2 = this.try2;
					
					this.try2 = r.nextInt(this.max2 - this.min2) + this.min2;
				}
			}
			
			if (!compareTry3(this.try3, this.number)) {
				if(this.try3 > (Integer.valueOf(splitNumber[2]) - '0')) {
					r = new Random();
					this.max3 = this.try3;
					
					this.try3 = r.nextInt(this.max3 - this.min3) + this.min3;
				}
				else {
					r = new Random();
					this.min3 = this.try3;
					
					this.try3 = r.nextInt(this.max3 - this.min3) + this.min3;
				}
			}
			
			if (!compareTry4(this.try4, this.number)) {
				if(this.try4 > (Integer.valueOf(splitNumber[3]) - '0')) {
					r = new Random();
					this.max4 = this.try4;
					
					this.try4 = r.nextInt(this.max4 - this.min4) + this.min4;
				}
				else {
					r = new Random();
					this.min4 = this.try4;
					
					this.try4 = r.nextInt(this.max4 - this.min4) + this.min4;
				}
			}
		}
	}
	
	public boolean compareTry1(int try1, int number){ // Renvoie true si la valeur des milliers de l'ordinateur correspond � celle envoy�e par le joueur et false si elle ne correspond pas. Effectue un test similaire pour les autres.
		String charNumber = String.valueOf(number);
		
		char[] splitNumber = charNumber.toCharArray();
		
		if(try1 == (Integer.valueOf(splitNumber[0]) - '0')) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean compareTry2(int try2, int number){
		String charNumber = String.valueOf(number);
		
		char[] splitNumber = charNumber.toCharArray();
		
		if(try2 == (Integer.valueOf(splitNumber[1]) - '0')) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean compareTry3(int try3, int number){
		String charNumber = String.valueOf(number);
		
		char[] splitNumber = charNumber.toCharArray();
		
		if(try3 == (Integer.valueOf(splitNumber[2]) - '0')) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean compareTry4(int try4, int number){
		String charNumber = String.valueOf(number);
		
		char[] splitNumber = charNumber.toCharArray();
		
		if(try4 == (Integer.valueOf(splitNumber[3]) - '0')) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public String convertFailIntoResult(int total, char[] splitNumber) { // Fonction cr�ant le print comparant le r�sultat de l'ordinateur � celui demand� par le joueur.
		this.vies--;
		
		String result = "";
		if (this.try1 < (Integer.valueOf(splitNumber[0]) - '0') ) { // Affiche + si le num�ro � trouver est plus grand que celui envoy�.
			result = result + "+";
		}
		else if(this.try1 > (Integer.valueOf(splitNumber[0]) - '0')) { // Affiche - si le num�ro � trouver est plus petit que celui envoy�.
			result = result + "-";
		}
		else if(this.try1 == (Integer.valueOf(splitNumber[0]) - '0')) { // Affiche = si le num�ro � trouver est �gal � celui envoy�.
			result = result + "=";
		}
		
		
		if (this.try2 < (Integer.valueOf(splitNumber[1]) - '0')) {
			result = result + "+";
		}
		else if(this.try2 > (Integer.valueOf(splitNumber[1]) - '0')) {
			result = result + "-";
		}
		else if(this.try2 == (Integer.valueOf(splitNumber[1]) - '0')) {
			result = result + "=";
		}
		
		
		if (this.try3 < (Integer.valueOf(splitNumber[2]) - '0')) {
			result = result + "+";
		}
		else if(this.try3 > (Integer.valueOf(splitNumber[2]) - '0')) {
			result = result + "-";
		}
		else if(this.try3 == (Integer.valueOf(splitNumber[2]) - '0')) {
			result = result + "=";
		}
		
		
		if (this.try4 < (Integer.valueOf(splitNumber[3]) - '0')) {
			result = result + "+";
		}
		else if(this.try4 > (Integer.valueOf(splitNumber[3]) - '0')) {
			result = result + "-";
		}
		else if(this.try4 == (Integer.valueOf(splitNumber[3]) - '0')) {
			result = result + "=";
		}
		
		return result;
		
	}
	
	public boolean winAct(int choice) {
		if (choice == 1) { // Remets les valeurs initiales pour pouvoir rejouer.
			this.number = 0;
			this.vies = 10;
			this.try1 = 5;
			this.try2 = 5;
			this.try3 = 5;
			this.try4 = 5;
			
			this.max1 = 9;
			this.max2 = 9;
			this.max3 = 9;
			this.max4 = 9;
			
			this.min1 = 0;
			this.min2 = 0;
			this.min3 = 0;
			this.min4 = 0;
			this.playGame();
			return true;
		}
		else if (choice == 2) {
			NombreMystere.main(null);
			return true;
		}
		else if (choice == 3) {
			System.exit(1);
			return true;
		}
		return false;
	}
}
